%% Initializing
clearvars
clc
fclose('all');
scrsz = get(groot, 'Screensize'); % for screen display purpose

p = mfilename('fullpath');
[filepath, name, ~] = fileparts(p);
addpath(filepath);

FRETbins = (-0.2 : 0.002 : 1.2)';
bin_cntrs = FRETbins(2 : end) - 0.001;

%% Setting up processing working place  ===========================================================================================================%
Path0 = uigetdir('', 'Choose the  Main  Directory'); % datasaving: path0 --> samplefolder --> spool files

SampleList = dir(Path0); 
isSampleDir = [SampleList(:).isdir];
SampleName = {SampleList(isSampleDir).name}';
SampleName(ismember(SampleName, {'.','..','map','Analysis','preview'})) = [];

%% FRET pairing  ===========================================================================================================%
for s = 1 : numel(SampleName)
    
    tic;
    CataList = dir([Path0 '\' SampleName{s} '\selected_*']);
    isCataDir = [CataList(:).isdir];
    CataName = {CataList(isCataDir).name}';
    CataName(ismember(CataName, {'.','..','selected_0','selected_4','selected_12'})) = [];
    
    Frq_raw = zeros(size(bin_cntrs));
    Frq_smooth = zeros(size(bin_cntrs));
    
    SpoolList = dir([Path0 '\' SampleName{s} '\*_FRET.mat']);
    [~, idx] = sort([SpoolList.datenum]);
    SpoolList = SpoolList(idx);
    SpoolNames = {SpoolList(:).name}';
    SpoolNames(contains(SpoolNames, ["_Left.mat", "_Right.mat"])) = [];
    
    Frq_spool_raw = zeros(size(bin_cntrs, 1), numel(SpoolNames));
    Frq_spool_smooth = zeros(size(bin_cntrs, 1), numel(SpoolNames));
    
    for c = 1 : numel(CataName)
        
        for sp = 1 : numel(SpoolNames)
            
            spname = [SpoolNames{sp}(1:end-9) '_mol_'];
            DataList = dir([Path0 '\' SampleName{s} '\' CataName{c} '\' spname '*.dat']);
            DataNames = {DataList(:).name}';
            DataNames(contains(DataNames, ['_ave.data', '_bkgd.data'])) = [];
        
            for ii = 1 : numel(DataNames)
        
                fid = fopen([Path0 '\' SampleName{s} '\' CataName{c} '\' DataNames{ii}]);
                fFRET = textscan(fid, '%f %f %f %f', 'HeaderLines', 1);
                fclose(fid);
                if ~isempty(fFRET{1})
                    D_raw = fFRET{2};
                    A_raw = fFRET{3};
                    FRET_raw = fFRET{4};
                    FRET_smooth = smooth(FRET_raw, 5);
            
                    [dummy, ~] = histcounts(FRET_raw, FRETbins);
                    Frq_spool_raw(:, sp) = Frq_spool_raw(:, sp) + dummy'; 
                    
                    [dummy, ~] = histcounts(FRET_smooth, FRETbins);
                    Frq_spool_smooth(:, sp) = Frq_spool_smooth(:, sp) + dummy'; 
                
                end
            end
            
        end
           
    end
    
    result_sp_raw = [bin_cntrs, Frq_spool_raw];
    result_sp_smooth = [bin_cntrs, Frq_spool_smooth];
    result_tot_raw = [bin_cntrs, sum(Frq_spool_raw, 2), sum(Frq_spool_raw, 2)/sum(Frq_spool_raw(:))];
    result_tot_smooth = [bin_cntrs, sum(Frq_spool_smooth, 2), sum(Frq_spool_smooth, 2)/sum(Frq_spool_smooth(:))];
    
    save([Path0 '\' SampleName{s} '\raw_tot_hist.histdata'], 'result_tot_raw', '-ASCII');
    save([Path0 '\' SampleName{s} '\smth_tot_hist.histdata'], 'result_tot_smooth', '-ASCII');
    save([Path0 '\' SampleName{s} '\raw_spool_hist.histdata'], 'result_sp_raw', '-ASCII');
    save([Path0 '\' SampleName{s} '\smth_spool_hist.histdata'], 'result_sp_smooth', '-ASCII');
    
    hist_fig = figure('Position', [0.1*scrsz(3)  0.125*scrsz(4)  0.8*scrsz(3) 0.8*scrsz(4)]);
    
    subplot(2, 2, 1);
    plot(bin_cntrs, Frq_spool_raw);
    
    subplot(2, 2, 2);
    bar(bin_cntrs, Frq_spool_smooth);
    
    subplot(2, 2, 3);
    plot(bin_cntrs, sum(Frq_spool_raw, 2));
    
    subplot(2, 2, 4);
    bar(bin_cntrs, sum(Frq_spool_smooth, 2));
    
    savefig(hist_fig, [Path0 '\' SampleName{s} '\raw_hist.fig'])
    clf(hist_fig); 
    close(hist_fig);
    toc;
    
end
