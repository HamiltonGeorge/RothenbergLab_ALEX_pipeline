clear all

microscope = 'NE'; % or NW

cpath=pwd;
[fname,fpath]=uigetfile('*.mat', 'MultiSelect', 'on');
cd(fpath);
pth=fpath;
Green = [];
Red = [];
DataOut = [];
Length = 900; %length of donor excitation window
TotalLength = 1000; %length of whole movie
ShiftBaseLine = 0; % to shift up the baseline if it is below 0. Initially run with 0! If ebFRET gives an error, set this value to >0. 
string = 'NE';

% for h = 1:size(fname,2) % this does not work properly if only 1 file is selected, find a solution
%     try
%         Data = load(fname{h});
%     catch
        Data = load(fname);
%     end
    next = size(DataOut,1);
    counter = 0;
%     keyboard
    for i = 1 : size(Data.FRET_pairs,2)
        if contains(microscope, string)
            Red = Data.FRET_pairs(i).RightI(1:Length)+ShiftBaseLine;
            LastRedFrames = Data.FRET_pairs(i).RightI(Length:TotalLength);
            Green = Data.FRET_pairs(i).LeftI(1:Length)+ShiftBaseLine;
        else
            Red = Data.FRET_pairs(i).LeftI(1:Length)+ShiftBaseLine;
            LastRedFrames = Data.FRET_pairs(i).LeftI(Length:TotalLength);
            Green = Data.FRET_pairs(i).RightI(1:Length)+ShiftBaseLine;
        end
%         Green = 1;
% keyboard
        %%%        
        if mean(LastRedFrames) > 50 
            counter = counter + 1;
            DataOut((next+((counter-1)*Length+1):(next+(counter*Length))),1) = i+next/Length;
            DataOut((next+((counter-1)*Length+1):(next+(counter*Length))),2) = Green;
            DataOut((next+((counter-1)*Length+1):(next+(counter*Length))),3) = Red;
        end
        %%%       

    end
% end

% Max = max(DataOut(:,3));
% DataOut(:,3) = DataOut(:,3)./Max;
% DataOut(:,2) = 1-DataOut(:,3);

save DataOutF.dat DataOut -ASCII