function [IdxMAX_x, IdxMAX_y, Mol_app] = LocalMax(ims, PSFsigma, boxsz, thresh_method, thresh_factor)
% Localize the [y, x] of the local maximum appearing through the ims stack 
%   ims: image stack
%   PSFsigma: unit in pixel, to determine the smoothing kernel size
%   boxsz: unit in pixel, must be odd, to exclude the local maxmum at image margins
%   thresh_method: 'std' -- use thresh_factor*std(F2-F1) as threshold; F2 and F1 are the 2nd and 1st order wavelet smoothed images.
%                  'const' -- use thresh_factor as threshold. 
%   thresh_factor: numerical coefficient for thresholding 

%% Image information
imszy = size(ims, 1);
imszx = size(ims, 2);

%% Rough localization of molecules
Mol_app = max(smoothdata(ims, 3, 'movmedian', 3), [], 3);

% wavelet smoothing and background extraction
K = getBSplineKernel(boxsz, 2, 3, 2*PSFsigma);
F1 = conv2(Mol_app, K(1).kernel, 'same');
F2 = conv2(Mol_app, K(2).kernel, 'same');
Mols = F1 - F2;

% thresholding
if strcmp(thresh_method, 'std')
    thresh = thresh_factor * std(Mols(:));
elseif strcmp(thresh_method, 'const')
    thresh = thresh_factor;
else
    error('thresh_method must be "std" or "const".');
end

% local maximum
Mols_max = imregionalmax(Mols) & (Mols > thresh);
ind = find(Mols_max);
IdxMAX_y = mod((ind-1), imszy) + 1;
IdxMAX_x = floor((ind-1)/imszy) + 1;

boxr = (boxsz - 1) / 2;
for i = 1 : size(ind, 1)
    tmp_foo = Mols((max((IdxMAX_y(i)-boxr), 1) : min((IdxMAX_y(i)+boxr), imszy)), (max((IdxMAX_x(i)-boxr), 1) : min((IdxMAX_x(i)+boxr), imszx)));
    if Mols(IdxMAX_y(i), IdxMAX_x(i)) < max(tmp_foo(:))
        IdxMAX_x(i) = -1;
        IdxMAX_y(i) = -1;
    end
end
boundmask = (IdxMAX_x<boxr+1) | (IdxMAX_x>imszx-boxr) | (IdxMAX_y<boxr+1) | (IdxMAX_y>imszy-boxr);
IdxMAX_y(boundmask) = [];
IdxMAX_x(boundmask) = [];
