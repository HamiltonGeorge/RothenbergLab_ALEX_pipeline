function [Kx, Ky] = polywarp(x_from, y_from, x_to, y_to, degree)

if size(x_from, 1) ~= size(y_from, 1) || size(x_to, 1) ~= size(y_to, 1)
    error('number of input x does not match that of input y');
end
if size(x_from, 1) ~= size(x_to, 1) || size(y_from, 1) ~= size(y_to, 1)
    error('number of reference x/y does not match that of transform x/y');
end
inputsz = size(x_from, 1);
transmat = zeros(inputsz, (degree+1)^2);

for pow = 1 : (degree+1)^2
    pow_x = floor((pow-1)/(degree+1));
    pow_y = mod((pow-1), (degree+1));
    transmat(:, pow) = x_from.^pow_x .* y_from.^pow_y;
end
Kx = transmat \ x_to;
Ky = transmat \ y_to;
end
