For extraction of traces from raw tiff files consisting of alternating frames of donor/acceptor excitation as well as color channel mapping with vertically split camera chip (left = donor, right = acceptor)

Bead images for mapping should be processed with channels_map_2chHalfChip_rgb_emccd.m

Then, images saved with prefix 'spool_' in folders labeled 'spool_' are processed by mainBatch_FRET_ALEX_wholeim_alltraces_test_splitimsel.m (or mainBatch_FRET.m for non-ALEX) to extract traces into .mat files

ALEX experiment movies are assumed to be ordered donor->acceptor->donor->acceptor..., and should be reordered if this is not the case

Output mat files can be converted to ebFRET format with 