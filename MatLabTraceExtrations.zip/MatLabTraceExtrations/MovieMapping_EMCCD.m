%% Initializing
clearvars;
close all
clc
p = mfilename('fullpath');
[filepath, name, ~] = fileparts(p);
addpath(filepath);

fname = 'spool';          % spool name, micromanager defalt is "spool"
imszx = 512;             % image width, defalt is 1200 pixel
imszy = 512;             % image height, defalt is 1200 pixel

%% Reading map information
[MapName, PathName] = uigetfile('*L2R.coor','Select map file');
FullMapName = [PathName, MapName];
[mappth, mname, ~] = fileparts(FullMapName);
PQ_right_img = dlmread(FullMapName);
P_right_img = PQ_right_img(1:size(PQ_right_img,1)/2);
Q_right_img = PQ_right_img(size(PQ_right_img,1)/2+1:size(PQ_right_img,1));

%% Setting up processing working place  ===========================================================================================================%
Path0 = uigetdir('', 'Choose the  Main  Directory'); % data saving: path0 (RGB) --> samplefolder --> spoolfolder --> spool files
[parentpth, ~, ~] = fileparts(Path0);
        
SampleList = dir(Path0); 
isSampleDir = [SampleList(:).isdir];
SampleName = {SampleList(isSampleDir).name}';
SampleName(ismember(SampleName, {'.','..','map','Analysis','preview'})) = [];

for s = 1 : numel(SampleName)
    if ~exist([parentpth '\Output\' SampleName{s}],'dir')
        mkdir([parentpth '\Output\' SampleName{s}]);
    end
end
 
for s = 1 : numel(SampleName)    
            
    SpoolList = dir([Path0 '\' SampleName{s} '\' fname '*.tif']);
    SpoolNames = {SpoolList(:).name}';
            
    for sp = 1 : numel(SpoolNames)
        
        outputpth_left = [parentpth '\Output\' SampleName{s} '\' SpoolNames{sp} '\lefts'];
        if ~exist(outputpth_left, 'dir')
            mkdir(outputpth_left);
        end
        outputpth_right = [parentpth '\Output\' SampleName{s} '\' SpoolNames{sp} '\rights'];
        if ~exist(outputpth_right, 'dir')
            mkdir(outputpth_right);
        end
        
        FullFileName = [Path0 '\' SampleName{s} '\' SpoolNames{sp}];
        tiffinfo = imfinfo(FullFileName);
        imgnum = numel(tiffinfo);
        
        disp(['working on ' SampleName{s} '-' SpoolNames{sp} ': ' num2str(imgnum) ' frames in total']);                
        tic
        warning('off','all');
        
        t = Tiff(FullFileName, 'r');
        for i = 1 : imgnum
            t.setDirectory(i);
            im = t.read();
            im_left = im(1:imszy, 1:floor(imszx/2));
            im_right = im(1:imszy, floor(imszx/2)+1:2*floor(imszx/2));
            im_mapped = movie_correction(im_right, P_right_img, Q_right_img);
            imwrite(im_left, [outputpth_left '\frm_' num2str(i) '.tif']);
            imwrite(im_mapped, [outputpth_right '\frm_' num2str(i) '.tif']);
        end
        t.close();
        warning('on','all');
    end
end