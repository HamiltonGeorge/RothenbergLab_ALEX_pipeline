clearvars
clc
fclose('all');

p = mfilename('fullpath');
[filepath, name, ~] = fileparts(p);
addpath(filepath);

%% ======================== user defined parameters =======================

% degree of polynomial in polywarp function
% higher degree doesn't always improve the accuracy
degree = 2; 
            

%% ========================= initializing parameters ======================

CameraPx = 160; % nm
imszx = 512; % px
imszy = 512; % px
psfsigma = 143; % nm
psfsigma = psfsigma / CameraPx; % px
boxr = ceil(2.355 * psfsigma); % px

[XX, YY] = meshgrid(-boxr : boxr, -boxr : boxr);
circle = double(ceil(sqrt(XX.^2 + YY.^2)) == boxr);
rect = double(abs(XX) == boxr | abs(YY) == boxr);


%% =================== reading and thresholding beads map =================

frame = zeros(imszy, floor(imszx/2), 2, 'double');
[FileName, PathName] = uigetfile('*.tif', 'Select the map tif');
maptif = imread([PathName FileName]);
frame(:, :, 1) = maptif(1 : imszy, 1 : floor(imszx/2));
frame(:, :, 2) = maptif(1 : imszy, floor(imszx/2)+1 : 2*floor(imszx/2));

% -------------------------- thresholds (modifiable) ----------------------
CH_left = frame(:, :, 1);
CH_left = imgaussfilt(CH_left, psfsigma) - imgaussfilt(CH_left, 2*psfsigma);
CH_left(CH_left < mean(CH_left(:)) + 4 * std(CH_left(:))) = 0;

CH_right = frame(:, :, 2);
CH_right = imgaussfilt(CH_right, psfsigma) - imgaussfilt(CH_right, 2*psfsigma);
CH_right(CH_right < mean(CH_right(:)) + 4 * std(CH_right(:))) = 0;
    

%% ====== building initial transformation basing on user picked beads =====

temp1 = cat(3, CH_left, CH_right, zeros(size(CH_left))); % temp1 always stores peaks
temp2 = temp1; % temp2 draws circles around

coor_left = zeros(9, 2); % restore the beads coordinates chosen by users [x y]
coor_right = zeros(9, 2);

trans_mat_L2R = zeros(9, 9); % will be using the left as the reference (map right to left)

scrsz = get(groot, 'Screensize');
room_ratio = min(scrsz(3) / (imszx/2), scrsz(4) / imszy);
windowsz = ceil(room_ratio .* [imszx / 2, imszy]);

h1 = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
ax1 = gca;
ax1.Position = ax1.OuterPosition;
set(gcf, 'MenuBar', 'none');
imagesc(temp1);
hold on

% ------------------- user picking beads ----------------------------------
for i = 1 : 9
    
    disp(['#' num2str(i) ' bead in left (shown in red): ']);
    coor_left(i, :) = ceil(myginput(1, 'crosshair')); % [x y]
    foo = CH_left(coor_left(i,2)-boxr:coor_left(i,2)+boxr, coor_left(i,1)-boxr:coor_left(i,1)+boxr);
    % correctting the manually picked pixel to the mass center of a bead PSF
    coor_left(i,1) = sum((coor_left(i,1)-0.5-boxr:coor_left(i,1)-0.5+boxr) .* sum(foo, 1), 2) / sum(foo(:));
    coor_left(i,2) = sum((coor_left(i,2)-0.5-boxr:coor_left(i,2)-0.5+boxr)' .* sum(foo, 2), 1) / sum(foo(:));
    
    Intensity_left = max(foo(:));
    for k = -boxr : boxr
        for m = -boxr : boxr
            if circle(k+boxr+1, m+boxr+1) == 1
                temp2(ceil(coor_left(i,2))+k, ceil(coor_left(i,1))+m, 1) = 0.75*Intensity_left;
            end
        end
    end
    imagesc(temp2);
    
    disp(['#' num2str(i) ' bead in right (shown in green): ']); % [x y]
    coor_right(i,:) = ceil(myginput(1, 'crosshair'));
    foo = CH_right(coor_right(i,2)-boxr:coor_right(i,2)+boxr, coor_right(i,1)-boxr:coor_right(i,1)+boxr);
    % correctting the manually picked pixel to the mass center of a bead PSF
    coor_right(i,1) = sum((coor_right(i,1)-0.5-boxr:coor_right(i,1)-0.5+boxr) .* sum(foo, 1), 2) / sum(foo(:));
    coor_right(i,2) = sum((coor_right(i,2)-0.5-boxr:coor_right(i,2)-0.5+boxr)' .* sum(foo, 2), 1) / sum(foo(:));
    
    Intensity_right = max(foo(:));
    for k = -boxr : boxr
        for m = -boxr : boxr
            if circle(k+boxr+1, m+boxr+1) == 1
                temp2(ceil(coor_right(i,2))+k, ceil(coor_right(i,1))+m, 2) = 0.75*Intensity_right;
            end
        end
    end
    imagesc(temp2);
    
end
hold off
clf(h1);
close(h1);

% ------- building transformation matrix using left as reference ----------- 
trans_mat_L2R(:,1) = 1; % x^0 * y^0
trans_mat_L2R(:,2) = coor_left(:,1); % x^1 * y^0
trans_mat_L2R(:,3) = coor_left(:,2); % x^0 * y^1
trans_mat_L2R(:,4) = coor_left(:,1) .* coor_left(:,2); % x^1 * y^1
trans_mat_L2R(:,5) = coor_left(:,1).^2; % x^2 * y^0
trans_mat_L2R(:,6) = coor_left(:,2).^2; % x^0 * y^2
trans_mat_L2R(:,7) = coor_left(:,1).^2 .* coor_left(:,2); % x^2 * y^1
trans_mat_L2R(:,8) = coor_left(:,1) .* coor_left(:,2).^2; % x^2 * y^1
trans_mat_L2R(:,9) = coor_left(:,1).^2 .* coor_left(:,2).^2; % x^2 * y^2

% ------------ generating transformation coefficient ----------------------
const_L2R = trans_mat_L2R \ coor_right; % [P_L2R Q_L2R] % '\' is not '/'


%% ================ Looking for good beads ================================
temp2 = temp1; % temp2 draws circles around

h1 = figure('Position', [scrsz(3)-min(scrsz(3), scrsz(4)) 0 min(scrsz(3), scrsz(4))/2 min(scrsz(3), scrsz(4))]);
ax1 = gca;
ax1.Position = ax1.OuterPosition;
set(gcf,'MenuBar','none');
imagesc(temp1);
hold on

% --------------- looking for good peaks in left channel ------------------ 
im_max_left = imregionalmax(CH_left);
idx_left = find(im_max_left);
coorx_left = floor((idx_left-1)/imszy) + 1;
coory_left = mod(idx_left-1, imszy) + 1;

margin_left = coorx_left < boxr+1 | coorx_left > floor(imszx/2) - boxr | coory_left < boxr+1 | coory_left > imszy - boxr;
idx_left(margin_left) = [];
coorx_left(margin_left) = [];
coory_left(margin_left) = [];

mask_left = true(size(idx_left, 1), 1);
for i = 1 : size(idx_left, 1)
    foo = CH_left(coory_left(i)-boxr:coory_left(i)+boxr, coorx_left(i)-boxr:coorx_left(i)+boxr);
    if foo(boxr+1, boxr+1) == max(foo(:)) % centroid criteria
        ring_lim = circle .* foo;
        if max(ring_lim(:)) < 0.5*(max(foo(:)) - min(foo(:))) % size criteria
            mask_left(i) = 0;
            for k = -boxr : boxr
                for m = -boxr : boxr
                    if circle(k+boxr+1, m+boxr+1) == 1
                        temp2(coory_left(i)+k, coorx_left(i)+m, 1) = 0.75 * max(foo(:));
                    end
                end
            end
            coorx_left(i) = sum((coorx_left(i)-0.5-boxr:coorx_left(i)-0.5+boxr) .* sum(foo, 1), 2) / sum(foo(:));
            coory_left(i) = sum((coory_left(i)-0.5-boxr:coory_left(i)-0.5+boxr)' .* sum(foo, 2), 1) / sum(foo(:));
        end
    end
end
idx_left(mask_left) = [];
coorx_left(mask_left) = [];
coory_left(mask_left) = [];

margin_left_2 = coorx_left < boxr+1 | coorx_left > floor(imszx/2) - boxr | coory_left < boxr+1 | coory_left > imszy - boxr;
idx_left(margin_left_2) = [];
coorx_left(margin_left_2) = [];
coory_left(margin_left_2) = [];

numOfleft = size(idx_left, 1);
disp(['there were ' num2str(numOfleft) ' good  Left  peaks']);


% ---------------- looking for good peaks in right channel ----------------
im_max_right = imregionalmax(CH_right);
idx_right = find(im_max_right);
coorx_right = floor((idx_right-1)/imszy) + 1;
coory_right = mod(idx_right-1, imszy) + 1;

margin_right = coorx_right < boxr+1 | coorx_right > floor(imszx/2) - boxr | coory_right < boxr+1 | coory_right > imszy - boxr;
idx_right(margin_right) = [];
coorx_right(margin_right) = [];
coory_right(margin_right) = [];

mask_right = true(size(idx_right, 1), 1);
for i = 1 : size(idx_right, 1)
    foo = CH_right(coory_right(i)-boxr:coory_right(i)+boxr, coorx_right(i)-boxr:coorx_right(i)+boxr);
    if foo(boxr+1, boxr+1) == max(foo(:)) % centroid criteria
        ring_lim = circle .* foo;
        if max(ring_lim(:)) < 0.5*(max(foo(:)) - min(foo(:))) % size criteria
            mask_right(i) = 0;
            for k = -boxr : boxr
                for m = -boxr : boxr
                    if circle(k+boxr+1, m+boxr+1) == 1
                        temp2(coory_right(i)+k, coorx_right(i)+m, 2) = 0.75 * max(foo(:));
                    end
                end
            end
            coorx_right(i) = sum((coorx_right(i)-0.5-boxr:coorx_right(i)-0.5+boxr) .* sum(foo, 1), 2) / sum(foo(:));
            coory_right(i) = sum((coory_right(i)-0.5-boxr:coory_right(i)-0.5+boxr)' .* sum(foo, 2), 1) / sum(foo(:));
        end
    end
end
idx_right(mask_right) = [];
coorx_right(mask_right) = [];
coory_right(mask_right) = [];

margin_right_2 = coorx_right < boxr+1 | coorx_right > floor(imszx/2) - boxr | coory_right < boxr+1 | coory_right > imszy - boxr;
idx_right(margin_right_2) = [];
coorx_right(margin_right_2) = [];
coory_right(margin_right_2) = [];

numOfright = size(idx_right, 1);
disp(['there were ' num2str(numOfright) ' good Right peaks']);

imagesc(temp2);


%% ============ roughly matching beads using initial transform ============
matrix_left = [ones(size(idx_left, 1), 1), coorx_left, coory_left, coorx_left.*coory_left, coorx_left.^2, coory_left.^2, coorx_left.^2.*coory_left, coorx_left.*coory_left.^2, coorx_left.^2.*coory_left.^2];
leftATright = matrix_left * const_L2R; %[leftATrightx leftATrighty]

matched_coorx_right = zeros(numOfleft, 1);
matched_coory_right = zeros(numOfleft, 1);

for i = 1 : numOfleft
    [nnd_leftATright,  matched_idx] = min(sqrt((coorx_right - leftATright(i,1)).^2 + (coory_right - leftATright(i,2)).^2));
    if nnd_leftATright < 3
        matched_coorx_right(i) = coorx_right(matched_idx);
        matched_coory_right(i) = coory_right(matched_idx);
        for k = -boxr : boxr
            for m = -boxr : boxr
                if rect(k+boxr+1, m+boxr+1) == 1
                    temp2(ceil(coory_left(i))+k, ceil(coorx_left(i))+m, 1) = max(CH_left(:));
                    temp2(ceil(coory_right(matched_idx))+k, ceil(coorx_right(matched_idx))+m, 2) = max(CH_right(:));
                end
            end
        end
    else
        matched_coorx_right(i) = -1;
        matched_coory_right(i) = -1;
    end
end

imagesc(temp2);

unmatched_idx = matched_coorx_right < 0 | matched_coory_right < 0;
coorx_left(unmatched_idx) = [];
coory_left(unmatched_idx) = [];
matched_coorx_right(unmatched_idx) = [];
matched_coory_right(unmatched_idx) = [];

hold off


%% ============ mapping channels using higher order polywarpping ==========

x_LR_pairs = [coorx_left, matched_coorx_right];
y_LR_pairs = [coory_left, matched_coory_right];

if size(x_LR_pairs, 1) > (degree+1)^2 
    
    disp(['found ' num2str(size(x_LR_pairs, 1)) ' Left/Right pairs']);

    % ------------ compare green optimizations and choose to save ----------
    [Kxright2left, Kyright2left] = polywarp(matched_coorx_right, matched_coory_right, coorx_left, coory_left, degree);
    tmp3 = cat(1, Kxright2left, Kyright2left);
    [Kxleft2right, Kyleft2right] = polywarp(coorx_left, coory_left, matched_coorx_right, matched_coory_right, degree);
    tmp4 = cat(1, Kxleft2right, Kyleft2right);
    
    save([PathName FileName '_R2L.coor'], 'tmp3', '-ASCII');
    save([PathName FileName '_L2R.coor'], 'tmp4', '-ASCII');
    
    
else
    disp('not enough matches');
end

save([PathName 'matched_LR_pairs_x.txt'], 'x_LR_pairs', '-ASCII');
save([PathName 'matched_LR_pairs_y.txt'], 'y_LR_pairs', '-ASCII');
