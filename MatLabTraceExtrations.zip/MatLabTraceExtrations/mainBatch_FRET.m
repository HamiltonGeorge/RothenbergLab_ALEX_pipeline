clearvars
clc
fclose('all');
scrsz = get(groot, 'Screensize');

p = mfilename('fullpath');
[filepath, name, ~] = fileparts(p);
cd(filepath);


%% ========================= Mapping information ==========================
% select a mapping method
%   'FRET':  read out trajactories with FRET signals;
%   'Left':  read out trajactories basing on the left channel;
%   'Right': read out trajactories basing on the right channel;
map_method = 'FRET'; 
nnd_thresh = 4; % unit: pixel

if strcmp(map_method, 'FRET') || strcmp(map_method, 'Right')
    [MapName, PathName] = uigetfile('*R2L.coor','Select the map .coor file');
    FullCoorName = [PathName, MapName];
    coeff = dlmread(FullCoorName);
    Kx = coeff(1:size(coeff,1)/2);
    Ky = coeff(size(coeff,1)/2+1:size(coeff,1));
elseif strcmp(map_method, 'Left')
    [MapName, PathName] = uigetfile('*L2R.coor','Select the map .coor file');
    FullCoorName = [PathName, MapName];
    coeff = dlmread(FullCoorName);
    Kx = coeff(1:size(coeff,1)/2);
    Ky = coeff(size(coeff,1)/2+1:size(coeff,1));
else
    error('map_method must be "FRET", "Left", or "Right".');
end


%% ============================= Parameters ===============================
% Camera settings
fname = 'spool'; % spool name, micromanager defalt is "spool"
imszx = 512; % unit: pixel, must be an even number
imszy = 512; % unit: pixel, must be an even number
CameraPxsz = 160; % unit: nm
PSFsigma = 143; % unit: nm, initial guess of the sigma of the Gaussian-PSF
PSFsigma = PSFsigma / CameraPxsz;

% Box settings. A single Gaussian-PSF will be evaluated in an area of boxsz x boxsz, must be odd.
%   boxr -- box 'radius'
%   EdgePxs -- Idxs of the pixels at the edge of the box
%   [centraly, centralx] -- Idx of the central pixel (This is why boxsz is required to be odd)
%   CentralPxs -- Idxs of the pixels at the central 3x3 of the box
boxsz = 7; % unit: px, 
boxr = (boxsz - 1) / 2; 
EdgePxs = [1 : boxsz, (boxsz-1)*boxsz+1 : (boxsz-1)*boxsz+boxsz, ((2:boxsz-1)-1)*boxsz+1, ((2:boxsz-1)-1)*boxsz+boxsz];
centraly = (boxsz + 1) / 2;
centralx = (boxsz + 1) / 2;
CentralPxs = [(centraly-2)*boxsz+(centralx-1 : centralx+1), (centraly-1)*boxsz+(centralx-1 : centralx+1), centraly*boxsz+(centralx-1 : centralx+1)];

% threshold settings
%   thresh_method--"std": thresh = thresh_factor * std(F2-F1) where F2 and F1 are the 2nd and 1st order smoothing (recommended).
%   thresh_method--"const": thresh = thresh_factor (e.g. 100).
thresh_method_L = "std"; 
thresh_factor_L = 1; % could be 2 if the mapping method is "Left".
thresh_method_R = "std";
thresh_factor_R = 3; % could be 2 if the mapping method is "Right".

% display settings
room_ratio = min(scrsz(3) / (imszx/2), scrsz(4) / imszy); % for screen display purpose
windowsz = ceil(room_ratio .* [(imszx/2), imszy]); % for screen display purpose


%% =============== Setting up processing working place  ===================
Path0 = uigetdir('', 'Choose the  Main  Directory'); % datasaving: path0 --> samplefolder --> spool files

SampleList = dir(Path0); 
isSampleDir = [SampleList(:).isdir];
SampleName = {SampleList(isSampleDir).name}';
SampleName(ismember(SampleName, {'.','..','map','Analysis','preview'})) = [];


%% ========================= Processing  ==================================
for s = 1 : numel(SampleName)
    
    SpoolList = dir([Path0 '\' SampleName{s} '\' fname '*.tif']);
    SpoolNames = {SpoolList(:).name}';
    SpoolNames(contains(SpoolNames, ['_ave.tif', '_bkgd.tif'])) = [];
    
    for sp = 1 : numel(SpoolNames)
        
        tic   
        disp(['working on ' SampleName{s} ' ' SpoolNames{sp}]);
        FullFileName = [Path0 '\' SampleName{s} '\' SpoolNames{sp}];
        fid = fopen([FullFileName(1:end-4) '_DataStat.txt'], 'w');
        
        % ================= Loading image ===================
        tiffinfo = imfinfo(FullFileName);
        imgnum = numel(tiffinfo);
        ims = zeros(imszy, imszx, imgnum, 'uint16'); % for large matrix, this will be faster than the function@cat
        warning('off','all');
        t = Tiff(FullFileName, 'r');
        for i = 1 : imgnum
            t.setDirectory(i);
            ims(:, :, i) = t.read();
        end
        t.close();
        warning('on','all');
        
        % =========== Splitting to Left and Right ===========
        ims_L = ims(:, 1 : imszx/2, :);
        ims_R = ims(:, imszx/2+1 : imszx, :);
        
        % ============ Localization and Mapping =============
        if strcmp(map_method, 'FRET')
            [Idx_x_L, Idx_y_L, Mol_L] = LocalMax(ims_L, PSFsigma, boxsz, thresh_method_L, thresh_factor_L);
            [Idx_x_R, Idx_y_R, Mol_R] = LocalMax(ims_R, PSFsigma, boxsz, thresh_method_R, thresh_factor_R);
            fprintf(fid,'%s %d\r\n', 'NumOfMol_on_Left', size(Idx_x_L, 1));
            fprintf(fid,'%s %d\r\n', 'NumOfMol_on_Right', size(Idx_x_R, 1));
            
            Mols_fig_L = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
            ax = gca;
            ax.Position = ax.OuterPosition;
            set(gcf, 'MenuBar', 'none');
            imagesc(Mol_L);
            colormap('gray');
            hold on
            plot(Idx_x_L, Idx_y_L, 'ro');
            hold off
            saveas(Mols_fig_L, [FullFileName(1:end-4), '_CHL.jpg'], 'jpg');
            clf(Mols_fig_L); 
            close(Mols_fig_L);

            Mols_fig_R = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
            ax = gca;
            ax.Position = ax.OuterPosition;
            set(gcf, 'MenuBar', 'none');
            imagesc(Mol_R);
            colormap('gray');
            hold on
            plot(Idx_x_R, Idx_y_R, 'ro');
            hold off
            saveas(Mols_fig_R, [FullFileName(1:end-4), '_CHR.jpg'], 'jpg');
            clf(Mols_fig_R); 
            close(Mols_fig_R);

            Idx_R2L = coor_correction([Idx_x_R, Idx_y_R], Kx, Ky);
            Idx_x_RatL = Idx_R2L(:, 1);
            Idx_y_RatL = Idx_R2L(:, 2);
            
            [nnd, dumidx] = pdist2([Idx_x_RatL, Idx_y_RatL], [Idx_x_L, Idx_y_L], 'euclidean', 'Smallest', 1);
            nnd_mask = nnd > nnd_thresh;
            dumidx(nnd_mask) = [];
            Idx_x_L(nnd_mask) = [];
            Idx_y_L(nnd_mask) = [];
            Idx_x_R = Idx_x_R(dumidx);
            Idx_y_R = Idx_y_R(dumidx);
            fprintf(fid,'%s %d\r\n', 'NumOf_FRET_pairs', size(Idx_x_R, 1));
            
            Mols_fig_FRET = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
            ax = gca;
            ax.Position = ax.OuterPosition;
            set(gcf, 'MenuBar', 'none');
            scatter(Idx_x_L, Idx_y_L, [], (1 : size(Idx_x_L, 1)));
            hold on
            scatter(Idx_x_RatL(dumidx), Idx_y_RatL(dumidx), [], (1 : size(Idx_x_L, 1)), '+');
            hold off
            colormap('jet');
            saveas(Mols_fig_FRET, [FullFileName(1:end-4), '_FRET.jpg'], 'jpg');
            clf(Mols_fig_FRET); 
            close(Mols_fig_FRET);
        
        elseif strcmp(map_method, 'Right')
            [Idx_x_R, Idx_y_R, Mol_R] = LocalMax(ims_R, PSFsigma, boxsz, thresh_method_R, thresh_factor_R);
            Idx_R2L = coor_correction([Idx_x_R, Idx_y_R], Kx, Ky);
            Idx_x_L = round(Idx_R2L(:, 1));
            Idx_y_L = round(Idx_R2L(:, 2));
            
            marginx_mask = Idx_x_L < boxr + 1 | Idx_x_L > (imszx/2 - boxr);
            marginy_mask = Idx_y_L < boxr + 1 | Idx_y_L > (imszy - boxr);
            Idx_x_L(marginx_mask | marginy_mask) = [];
            Idx_y_L(marginx_mask | marginy_mask) = [];
            Idx_x_R(marginx_mask | marginy_mask) = [];
            Idx_y_R(marginx_mask | marginy_mask) = [];
            fprintf(fid,'%s %d\r\n', 'NumOfMol_on_Right', size(Idx_x_R, 1));
            
            Mols_fig_R = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
            ax = gca;
            ax.Position = ax.OuterPosition;
            set(gcf, 'MenuBar', 'none');
            imagesc(Mol_R);
            colormap('gray');
            hold on
            plot(Idx_x_R, Idx_y_R, 'ro');
            hold off
            saveas(Mols_fig_R, [FullFileName(1:end-4), '_CHR.jpg'], 'jpg')
            clf(Mols_fig_R); 
            close(Mols_fig_R);
        
        elseif strcmp(map_method, 'Left')
            [Idx_x_L, Idx_y_L, Mol_L] = LocalMax(ims_L, PSFsigma, boxsz, thresh_method_L, thresh_factor_L);
            Idx_L2R = coor_correction([Idx_x_L, Idx_y_L], Kx, Ky);
            Idx_x_R = round(Idx_L2R(:, 1));
            Idx_y_R = round(Idx_L2R(:, 2));
            
            marginx_mask = Idx_x_R < boxr + 1 | Idx_x_R > (imszx/2 - boxr);
            marginy_mask = Idx_y_R < boxr + 1 | Idx_y_R > (imszy - boxr);
            Idx_x_L(marginx_mask | marginy_mask) = [];
            Idx_y_L(marginx_mask | marginy_mask) = [];
            Idx_x_R(marginx_mask | marginy_mask) = [];
            Idx_y_R(marginx_mask | marginy_mask) = [];
            fprintf(fid,'%s %d\r\n', 'NumOfMol_on_Left', size(Idx_x_L, 1));

            Mols_fig_L = figure('Position', [scrsz(3)-windowsz(1)  scrsz(4)-windowsz(2)  windowsz(1) windowsz(2)]);
            ax = gca;
            ax.Position = ax.OuterPosition;
            set(gcf, 'MenuBar', 'none');
            imagesc(Mol_L);
            colormap('gray');
            hold on
            plot(Idx_x_L, Idx_y_L, 'ro');
            hold off
            saveas(Mols_fig_L, [FullFileName(1:end-4), '_CHL.jpg'], 'jpg')
            clf(Mols_fig_L); 
            close(Mols_fig_L);

        else
            error('Mapping method must be "FRET", "Right", or "Left"');
        
        end
        fclose(fid);

        % ============= Extracting Trajactories =================
        % Median of the pxs at the box edge is the bkg
        % Mean of the pxs at the box center is the I
        numOfPairs = size(Idx_x_L, 1);
        FRET_pairs = struct([]);
        for n = 1 : numOfPairs
            
            dum = double(ims_L(Idx_y_L(n)-boxr:Idx_y_L(n)+boxr, Idx_x_L(n)-boxr:Idx_x_L(n)+boxr, :));
            dum = reshape(dum, boxsz*boxsz, []);
            dum_bkg = dum(EdgePxs, :);
            dum_I = dum(CentralPxs, :);
            bkg = median(dum_bkg, 1);
            I = mean(dum_I, 1);
            FRET_pairs(n).LeftI = (I - bkg)';
            FRET_pairs(n).LeftCoors = [Idx_x_L(n), Idx_y_L(n)]; %[x, y]

            dum = double(ims_R(Idx_y_R(n)-boxr:Idx_y_R(n)+boxr, Idx_x_R(n)-boxr:Idx_x_R(n)+boxr, :));
            dum = reshape(dum, boxsz*boxsz, []);
            dum_bkg = dum(EdgePxs, :);
            dum_I = dum(CentralPxs, :);
            bkg = median(dum_bkg, 1);
            I = mean(dum_I, 1);
            FRET_pairs(n).RightI = (I - bkg)';
            FRET_pairs(n).RightCoors = [Idx_x_R(n), Idx_y_R(n)]; %[x, y]
        end
        save([FullFileName(1:end-4) '_FRET.mat'], 'FRET_pairs');
        toc
        
    end
end
