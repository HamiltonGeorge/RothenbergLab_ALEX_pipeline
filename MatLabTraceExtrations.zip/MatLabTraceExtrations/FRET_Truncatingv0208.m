%% Initializing
clearvars
clc
fclose('all');
scrsz = get(groot, 'Screensize'); % for screen display purpose

timeres = 0.2; % unit = s
Acceptor = 'Right'; % if it's not 'Right', 'R', or 'r', the acceptor channel will be assigned to the left side
D_color = [0.4660 0.6740 0.1880];
A_color = [0.8500 0.3250 0.0980];
FRET_color = [0 0.4470 0.7410];

% Setting up working place
SampleFolder = uigetdir('', 'Choose one Sample Directory for processing'); % datasaving: samplefolder --> spool files

% Searching for FRET.mat
SpoolList = dir([SampleFolder '\*_FRET_FRET.mat']);
SpoolNames = {SpoolList(:).name}';
SpoolNames(contains(SpoolNames, ["_Left.mat", "_Right.mat"])) = [];

for ii = 1 : numel(SpoolNames)
    
    spname = SpoolNames{ii}(1:end-9);
    load([SampleFolder '\' SpoolNames{ii}]);
    numMols = numel(FRET_pairs);
    
    jj = 1;
    while jj <= numMols
        
        if strcmp(Acceptor, 'Right') || strcmp(Acceptor, 'R') || strcmp(Acceptor, 'r')
            CHD = FRET_pairs(jj).LeftI;
            CHA = FRET_pairs(jj).RightI;
        else
            CHA = FRET_pairs(jj).LeftI;
            CHD = FRET_pairs(jj).RightI;
        end
        CHD_smooth = smooth(CHD, 5);
        CHA_smooth = smooth(CHA, 5);
        
        time = (1 : max(size(CHD, 1), size(CHA, 1)))';
        bins = (-0.2 : 0.02 : 1.2)';
        FRET = CHA ./ (CHA + CHD);
        FRET(CHA + CHD == 0) = 0;
        FRET_smooth = CHA_smooth ./ (CHA_smooth + CHD_smooth);
        
        mol_fig = figure('Position', [0.05*scrsz(3)  0.0625*scrsz(4)  0.9*scrsz(3) 0.9*scrsz(4)]);
        
        subplot(4, 1, 1);
        plot(time, CHD, '-', 'Color', D_color);
        hold on
        plot(time, CHA, '-', 'Color', A_color);
        hold off
        grid on
        title(['Donor-Acceptor Intesities: Molecule ' num2str(jj) ' ' spname], 'Interpreter', 'none');

        subplot(4, 1, 2);
        plot(time, (CHD + CHA), 'k-');
        grid on
        title(['Total Intesities: Molecule ' num2str(jj) ' ' spname], 'Interpreter', 'none');
        
        subplot(4, 1, 3);
        plot(time, FRET, 'o', 'MarkerEdgeColor', 'none', 'MarkerFaceColor', FRET_color);
        hold on
        plot(time, FRET_smooth, 'k-', 'LineWidth', 1);
        hold off
        grid on
        set(gca, 'YLim', [-0.15, 1.15]);
        title(['FRET: Molecule ' num2str(jj) ' ' spname], 'Interpreter', 'none');
        
        subplot(4, 1, 4);
        histogram(FRET_smooth, bins);
        title(['Histogram of smoothed FRET: Molecule ' num2str(jj) ' ' spname], 'Interpreter', 'none');
   
        usropt = input('Press "s" to save, "t" to truncate before saving, "b" to go back to the last molecule, or "q" for the next spool. Press Enter to pass.','s');
        
        if isempty(usropt) 
            disp('skip');
        end
        
        if strcmp(usropt, 'q')
            disp('Jumping to the next spool');
            clf(mol_fig); 
            close(mol_fig);
            break % jump to the next spool
        end
        
        if strcmp(usropt, 'n')
            jpto = input('Jump to which molecule? [Enter for Mol 1]');
            if isempty(jpto)
                jpto = 1;
            end
            jj = jpto;
            clf(mol_fig); 
            close(mol_fig);
            continue
        end
        
        if strcmp(usropt, 'k')
            CH_correct = input('Which channel needs to be corrected? [D/A]', 's'); 
            if strcmp(CH_correct, 'D')
                disp('Click on the start of the bleached fragment');
                [st, ~] = ginput(1);
                if isempty(st) || st < 0
                    st = time(1);
                end
                st = ceil(st);
                
                disp('Click on the end of the bleached fragment');
                [ed, ~] = ginput(1);
                if isempty(ed) || ed > time(end)
                    ed = time(end);
                end
                ed = floor(ed);
                while ed <= st
                    disp('the end point must be after the start point');
                    [ed, ~] = ginput(1);
                    ed = floor(ed);
                end
                
                CHD = CHD - mean(CHD(st : ed));
                FRET_pairs(jj).LeftI = CHD;
                jj = jj - 1;
            elseif strcmp(CH_correct, 'A')
                disp('Click on the start of the bleached fragment');
                [st, ~] = ginput(1);
                if isempty(st) || st < 0
                    st = time(1);
                end
                st = ceil(st);
                
                disp('Click on the end of the bleached fragment');
                [ed, ~] = ginput(1);
                if isempty(ed) || ed > time(end)
                    ed = time(end);
                end
                ed = floor(ed);
                while ed <= st
                    disp('the end point must be after the start point');
                    [ed, ~] = ginput(1);
                    ed = floor(ed);
                end
                
                CHA = CHA - mean(CHA(st : ed));
                FRET_pairs(jj).RightI = CHA;
                jj = jj - 1;
            end
               
        end % end of usroption = t
        
        if strcmp(usropt, 't')
            numFrag = input('how many events? [Enter for 1 event]'); 
            if isempty(numFrag)
                numFrag = 1;
            end
            for kk = 1 : numFrag
                
                disp(['Click on the start of the #' num2str(kk) ' fragment']);
                [st, ~] = ginput(1);
                if isempty(st) || st < 0
                    st = time(1);
                end
                st = ceil(st);
                
                disp(['Click on the end of the #' num2str(kk) ' fragment']);
                [ed, ~] = ginput(1);
                if isempty(ed) || ed > time(end)
                    ed = time(end);
                end
                ed = floor(ed);
                while ed <= st
                    disp('the end point must be after the start point');
                    [ed, ~] = ginput(1);
                    ed = floor(ed);
                end
                
                numCata = input('Select a directory to save? [Enter or 0 for selected_0, 1 for selected_1, 2 for selected_2,...]'); %choosing a directory
                if isempty(numCata)
                    Cata = '\selected_0';
                    if ~exist([SampleFolder Cata], 'dir')
                        mkdir([SampleFolder Cata]);
                    end
                else
                    Cata = ['\selected_' num2str(numCata)];
                    if ~exist([SampleFolder Cata], 'dir')
                        mkdir([SampleFolder Cata]);
                    end
                end
                fname1 = [SampleFolder Cata '\' spname '_mol_' num2str(jj) '_tr_' num2str(kk) '.dat']; 
                output = [time(st : ed).*timeres, CHD(st : ed), CHA(st : ed), FRET(st : ed)]';    
                fid = fopen(fname1, 'w');
                fprintf(fid, '%s %s %s %s\r\n', 'time(s)', 'Donor', 'Acceptor', 'FRET');
                fprintf(fid, '%f %f %f %f\r\n', output);
                fclose(fid);
            end   
        end % end of usroption = t
   
        if strcmp(usropt, 's')
            numCata = input('Select a directory to save? [Enter or 0 for selected_0, 1 for selected_1, 2 for selected_2,...]'); %choosing a directory
            if isempty(numCata)
                Cata = '\selected_0';
                if ~exist([SampleFolder Cata], 'dir')
                    mkdir([SampleFolder Cata]);
                end
            else
                Cata = ['\selected_' num2str(numCata)];
                if ~exist([SampleFolder Cata], 'dir')
                    mkdir([SampleFolder Cata]);
                end
            end
            fname1 = [SampleFolder Cata '\' spname '_mol_' num2str(jj) '_tr_0.dat']; 
            output = [time.*timeres, CHD, CHA, FRET]';    
            fid = fopen(fname1, 'w');
            fprintf(fid, '%s %s %s %s\r\n', 'time(s)', 'Donor', 'Acceptor', 'FRET');
            fprintf(fid, '%f %f %f %f\r\n', output);
            fclose(fid);   
        end
        
        if strcmp(usropt, 'b')
            if jj > 2
                jj = jj - 2;
            else
                jj = 0;
            end
        end
   
        clf(mol_fig); 
        close(mol_fig);
        jj = jj + 1;
    end
end